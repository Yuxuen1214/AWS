<?php include 'head.php'; ?>

<?php
// Include the homepage content
include 'homepage.php';
?>

<?php include 'foot.php'; ?>