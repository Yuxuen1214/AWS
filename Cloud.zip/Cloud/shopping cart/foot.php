    <footer>
        <p>&copy; <?php echo date("Y"); ?> Shopping Cart. All rights reserved.</p>
    </footer>
</body>
</html>
