-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2025 at 04:12 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user_actions`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminID` varchar(30) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminID`, `name`, `email`, `password`) VALUES
('ADM123', 'idio12', '10@gmail.com', '$2y$10$.h6cgZOEQW8AJEJ3fDKxCeyrQV35XdFGe9UIbAToVtZR2sJvYJN9y');

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `brandID` varchar(100) NOT NULL,
  `brandname` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `productID` varchar(100) NOT NULL,
  `customerID` varchar(100) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `quantity` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`productID`, `customerID`, `pname`, `quantity`) VALUES
('SHOE032', 'CUS702231', 'adidas by Stella McCartney Slide Shoes', 7);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customerID` varchar(30) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `email_verified` tinyint(1) DEFAULT 0,
  `password` varchar(255) NOT NULL,
  `address` varchar(500) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customerID`, `name`, `email`, `email_verified`, `password`, `address`, `birthdate`, `phone`, `profile_picture`) VALUES
('CUS702231', 'Leo Lim', '1@gmail.com', 0, '$2y$10$MZOU/J7weXIuYLiPXFwaKu79MUF0pMjReQiEU5PECXlScodk20Lly', '289\'D West Jelutong(same road lintang penawar 3)', '2006-01-05', '+60124118711', 'assets/images/profile_pictures/CUS702231_1745929044_gar.png'),
('CUS940488', 'try 2', '2@gmail.com', 0, '$2y$10$1w0HuC3Zw2UG23xy5I.Zxu6Jhm1BG5XASIsnhjbrfCsd3p252gL.K', NULL, NULL, NULL, 'assets/images/profile_pictures/CUS940488_1745918884_b5d8c3c4_0cc2_4936_9f3c_eaca1a3d69a1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `orderID` varchar(40) NOT NULL,
  `customerID` varchar(30) DEFAULT NULL,
  `order_date` datetime NOT NULL DEFAULT current_timestamp(),
  `total_amount` decimal(10,2) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'Processing',
  `shipping_name` varchar(100) DEFAULT NULL,
  `shipping_address` varchar(500) DEFAULT NULL,
  `shipping_phone` varchar(20) DEFAULT NULL,
  `payment_status` varchar(20) DEFAULT 'Paid',
  `tracking_number` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderID`, `customerID`, `order_date`, `total_amount`, `status`, `shipping_name`, `shipping_address`, `shipping_phone`, `payment_status`, `tracking_number`) VALUES
('ORD-6810DBE0B1A09', 'CUS702231', '2025-04-29 16:02:08', 698.00, 'On Hold', 'Leo Lim', '289\'D West Jelutong(same road lintang penawar 3)', '+60124118711', 'Paid', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `order_item_id` int(11) NOT NULL,
  `orderID` varchar(40) NOT NULL,
  `productID` varchar(40) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price_at_purchase` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`order_item_id`, `orderID`, `productID`, `quantity`, `price_at_purchase`) VALUES
(28, 'ORD-681096D7251B8', 'SHOE032', 3, 199.00),
(29, 'ORD-6810DBE0B1A09', 'SHOE032', 1, 199.00),
(30, 'ORD-6810DBE0B1A09', 'SHOE037', 1, 499.00);

-- --------------------------------------------------------

--
-- Table structure for table `persistent_cart`
--

CREATE TABLE `persistent_cart` (
  `cart_item_id` int(10) UNSIGNED NOT NULL,
  `customerID` varchar(30) NOT NULL,
  `productID` varchar(40) NOT NULL,
  `quantity` int(10) UNSIGNED NOT NULL DEFAULT 1,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `porder`
--

CREATE TABLE `porder` (
  `orderID` varchar(40) NOT NULL,
  `productID` varchar(100) NOT NULL,
  `customerID` varchar(100) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `totalprice` double(7,2) NOT NULL,
  `orderstatus` varchar(200) NOT NULL,
  `paymentstatus` varchar(10) NOT NULL,
  `shippingadd` varchar(1000) NOT NULL,
  `notracking` int(200) NOT NULL,
  `orderdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `productID` varchar(40) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `price` double(7,2) NOT NULL,
  `description` varchar(10000) NOT NULL,
  `sizeoption` varchar(10) NOT NULL,
  `color` varchar(100) NOT NULL,
  `stockquantity` int(200) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productID`, `pname`, `brand`, `category`, `price`, `description`, `sizeoption`, `color`, `stockquantity`, `image_path`) VALUES
('SHOE026', 'Ultraboost 22', 'Adidas', 'Running', 849.00, 'Primeknit+ upper, Boost midsole', '6,7,8,9,10', 'Blue', 50, 'images/products/SHOE026.jpg'),
('SHOE027', 'NMD R1', 'Adidas', 'Casual', 599.00, 'Boost cushioning, signature EVA plugs', '5,6,7,8,9,', 'Core Black', 35, 'images/products/SHOE027.jpg'),
('SHOE028', 'Stan Smith', 'Adidas', 'Lifestyle', 399.00, 'Classic leather, perforated stripes', '5,6,7,8,9,', 'White/Green', 28, 'images/products/SHOE028.jpg'),
('SHOE032', 'Adilette 22', 'Adidas', 'Slides', 199.00, 'Cloudfoam comfort slides', '6,7,8,9,10', 'White', 74, 'images/products/SHOE032.jpg'),
('SHOE033', 'Terrex Free Hiker', 'Adidas', 'Hiking', 899.00, 'Waterproof hiking shoe', '6,7,8,9,10', 'Black', 12, 'images/products/SHOE033.jpg'),
('SHOE037', 'Air Force 1', 'Nike', 'Lifestyle', 499.00, 'Classic all-leather design', '5,6,7,8,9,', 'White', 21, 'images/products/SHOE037.jpg'),
('SHOE040', 'React Infinity Run', 'Nike', 'Running', 699.00, 'Flyknit upper, React foam', '6,7,8,9,10', 'Bright Crimson', 25, 'images/products/SHOE040.jpg'),
('SHOE042', 'Tanjun', 'Nike', 'Casual', 299.00, 'Minimalist lightweight design', '5,6,7,8,9,', 'Pink', 40, 'images/products/SHOE042.jpg'),
('SHOE043', 'Metcon 7', 'Nike', 'Training', 549.00, 'Stable heel for weightlifting', '6,7,8,9,10', 'Black/Red', 130, 'images/products/SHOE043.jpg'),
('SHOE046', 'RS-X3 Puzzle', 'Puma', 'Retro', 499.00, 'Mixed-material chunky design', '6,7,8,9,10', 'Pink', 45, 'images/products/SHOE046.jpg'),
('SHOE048', 'Suede Classic', 'Puma', 'Lifestyle', 349.00, 'Signature Formstrip branding', '5,6,7,8,9,', 'Black', 51, 'images/products/SHOE048.jpg'),
('SHOE050', 'Deviate Nitro', 'Puma', 'Running', 799.00, 'Carbon plate for propulsion', '6,7,8,9,10', 'Electric Blue', 100, 'images/products/SHOE050.jpg'),
('SHOE051', 'Carina 2.0', 'Puma', 'Casual', 299.00, 'SoftFoam+ comfort insole', '5,6,7,8,9,', 'White', 48, 'images/products/SHOE051.jpg'),
('SHOE052', 'Ralph Sampson Low', 'Puma', 'Retro', 449.00, 'Bold basketball heritage', '6,7,8,9,10', 'Red/Blue', 14, 'images/products/SHOE052.jpg'),
('SHOE056', 'GOwalk 6', 'Skechers', 'Walking', 299.00, 'Lightweight with ULTRA GO', '5,6,7,8,9,', 'Navy', 60, 'images/products/SHOE056.jpg'),
('SHOE057', 'D\'Lites 3.0', 'Skechers', 'Casual', 349.00, 'Chunky dad sneaker', '5,6,7,8,9,', 'Black', 65, 'images/products/SHOE057.jpg'),
('SHOE064', 'Work Relaxed Fit', 'Skechers', 'Workwear', 349.00, 'Slip-resistant outsole', '6,7,8,9,10', 'Brown', 30, 'images/products/SHOE064.jpg'),
('SHOE065', 'Microburst', 'Skechers', 'Running', 299.00, 'Lightweight performance', '5,6,7,8,9,', 'Red', 25, 'images/products/SHOE065.jpg'),
('SHOE066', 'Old Skool', 'Vans', 'Skate', 279.00, 'Signature side stripe', '6,7,8,9,10', 'Black/White', 40, 'images/products/SHOE066.jpg'),
('SHOE070', 'Era', 'Vans', 'Skate', 269.00, 'Padded collar for skating', '6,7,8,9,10', 'Blue', 33, 'images/products/SHOE070.jpg'),
('SHOE071', 'Ultrarange', 'Vans', 'Lifestyle', 399.00, 'Cushioned for all-day wear', '6,7,8,9,10', 'Grey', 20, 'images/products/SHOE071.jpg'),
('SHOE072', 'ComfyCush Old Skool', 'Vans', 'Casual', 349.00, 'Enhanced cushioning', '6,7,8,9,10', 'Black', 25, 'images/products/SHOE072.jpg'),
('SHOE075', 'BMX Style 114', 'Vans', 'Action', 379.00, 'Reinforced for BMX riding', '6,7,8,9,10', 'Grey', 15, 'images/products/SHOE075.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminID`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`brandID`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD KEY `productID` (`productID`,`customerID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customerID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`orderID`),
  ADD KEY `customerID` (`customerID`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `orderID` (`orderID`),
  ADD KEY `productID` (`productID`);

--
-- Indexes for table `persistent_cart`
--
ALTER TABLE `persistent_cart`
  ADD PRIMARY KEY (`cart_item_id`),
  ADD UNIQUE KEY `customer_product` (`customerID`,`productID`),
  ADD KEY `idx_customer` (`customerID`),
  ADD KEY `idx_product` (`productID`);

--
-- Indexes for table `porder`
--
ALTER TABLE `porder`
  ADD PRIMARY KEY (`orderID`),
  ADD KEY `productID` (`productID`,`customerID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productID`);
ALTER TABLE `product` ADD FULLTEXT KEY `ft_search` (`pname`,`brand`,`description`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `order_item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `persistent_cart`
--
ALTER TABLE `persistent_cart`
  MODIFY `cart_item_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `persistent_cart`
--
ALTER TABLE `persistent_cart`
  ADD CONSTRAINT `fk_cart_customer` FOREIGN KEY (`customerID`) REFERENCES `customer` (`customerID`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_cart_product` FOREIGN KEY (`productID`) REFERENCES `product` (`productID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
